package com.example.practica10;

import android.app.Dialog;

public class Dialog extends Dialog {
}
