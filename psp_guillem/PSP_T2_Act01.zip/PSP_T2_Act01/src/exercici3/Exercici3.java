/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercici3;

import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Itzanh
 */
public class Exercici3 implements Runnable {

    public static final int NUM_TIRADES = 3;
    private static Semaphore finalitzats = new Semaphore(0);

    private String nom;
    private MonitorDau monitor;

    public Exercici3(String nom, MonitorDau monitor) {
        this.nom = nom;
        this.monitor = monitor;
    }

    @Override
    public void run() {
        int tirada = (int) Math.floor(Math.random() * 6) + 1;
        System.out.println(this.nom + " ha tirat i li ha eixit " + tirada);
        this.monitor.setTirada(tirada);
        finalitzats.release();
    }

    public static void main(String[] args) {
        // gestor de fils
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(3);

        // monitor de tirades
        MonitorDau monitor = new MonitorDau();

        // posar el marxa tots els fils necessaris del executor
        for (int i = 0; i < NUM_TIRADES; i++) {
            executor.execute(new Exercici3("El dau " + i, monitor));
        }

        // apagar el gestor i esperar a que els processos finalitzen
        executor.shutdown();
        for (int i = 0; i < NUM_TIRADES; i++) {
            try {
                finalitzats.acquire();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

        // mostrem el resultat del monitor per pantalla
        System.out.println("Tot tirat! El resultat es " + monitor.getTotal());
    }
}
