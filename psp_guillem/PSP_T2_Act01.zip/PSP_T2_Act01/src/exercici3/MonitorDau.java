/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercici3;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Itzanh
 */
public class MonitorDau {

    private int total;
    private Semaphore MUTEX;

    public MonitorDau() {
        this.total = 0;
        this.MUTEX = new Semaphore(1);
    }

    /**
     * Llig de una manera <i>thread-safe</i> el comptador que acumula les
     * tirades dels daus fins ara.
     *
     * @return El valor actual del comptador, o -1 si no ex pot llegir (se ha
     * produit un error).
     */
    public int getTotal() {
        try {
            int tornarTotal;
            MUTEX.acquire();
            tornarTotal = this.total;
            MUTEX.release();
            return tornarTotal;
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return -1;
    }

    /**
     * Acumula una tirada al comptador de una manera <i>thread-safe</i>.
     *
     * @param total tirada a acumular
     * @return true si la operació se ha realitzat correctament, i false si se
     * ha produit un error.
     */
    public boolean setTirada(int tirada) {
        try {
            MUTEX.acquire();
            this.total += tirada;
            MUTEX.release();

            return true;
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return false;
    }

}
