/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_t2_act01;

import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Itzanh
 */
public class Exercici2 implements Runnable {

    public static final int NUM_FILS = 2;
    private static Semaphore finalitzats = new Semaphore(0);

    private String cadena;

    public Exercici2(String cadena) {
        this.cadena = cadena;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(this.cadena + ". Per " + i + " volta ho dic xe.");
        }
        finalitzats.release();
    }

    public static void main(String[] args) {
        // gestor de fils
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);

        // posar el marxa tots els fils necessaris del executor
        for (int i = 0; i < NUM_FILS; i++) {
            executor.execute(new Exercici2("Esta es la cadena " + i));
        }

        // apagar el gestor i esperar a que els processos finalitzen
        executor.shutdown();
        for (int i = 0; i < NUM_FILS; i++) {
            try {
                finalitzats.acquire();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

        System.out.println("=== El programa ha finalitzat. ===");
    }

}
