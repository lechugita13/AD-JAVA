/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_t2_act01;

/**
 *
 * @author Itzanh
 */
public class Exercici1 extends Thread {

    public static final int NUM_FILS = 2;

    private String cadena;

    public Exercici1(String cadena) {
        this.cadena = cadena;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(i + " " + cadena);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Exercici1[] fils = new Exercici1[NUM_FILS];

        // crear els objectes dels fils
        for (int i = 0; i < NUM_FILS; i++) {
            fils[i] = new Exercici1("Esta es la cadena " + i);
        }

        // iniciar els fils
        for (int i = 0; i < NUM_FILS; i++) {
            fils[i].start();
        }

        // esperar a que acaben tots
        for (int i = 0; i < NUM_FILS; i++) {
            try {
                fils[i].join();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }

        System.out.println("=== El programa ha finalitzat. ===");
    }

}
