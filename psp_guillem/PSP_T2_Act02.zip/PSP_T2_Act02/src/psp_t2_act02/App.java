/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_t2_act02;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 *
 * @author Itzanh
 */
public class App {

    public static final int MAX_COCHES = 40;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // gestor de fils
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(4);

        // crear el monitor per a passarlo als cotxers
        MonitorAparcament monitor = new MonitorAparcament();

        // executar els coches
        for (int i = 0; i < MAX_COCHES; i++) {
            executor.execute(new Coche(i, monitor));
        }

        executor.shutdown();

    }

}
