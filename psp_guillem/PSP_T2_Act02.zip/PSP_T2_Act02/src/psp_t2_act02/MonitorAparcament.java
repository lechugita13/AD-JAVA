/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_t2_act02;

import java.util.concurrent.Semaphore;

/**
 *
 * @author Itzanh
 */
public class MonitorAparcament {

    public static final int MAX_PLACES = 10;

    private Semaphore placesLluires;
    private Semaphore placesOcupates;

    public MonitorAparcament() {
        placesLluires = new Semaphore(MAX_PLACES);
        placesOcupates = new Semaphore(0);
    }

    /**
     * Cridar a aquesta funcio bloqueja el fil que ho ejecute. Espera a que hi
     * haguen plaçes de aparcament lluires i al haber, desbloqueja el fil i
     * decrementa el numero de places lluires.
     *
     * @return true en cas de funcionar correctament, false en cas de excepcio
     * en els semafors.
     */
    public boolean entrarAparcament() {
        try {
            placesLluires.acquire();
            placesOcupates.release();

            return true;
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    /**
     * Incrementa el nombre de places lluires, decrementa el de les places
     * ocupades, i avisa als cotxes que puguen estar esperant que hi ha un lloc
     * lliure que ha deixat.
     *
     * @return true en cas de funcionar correctament, false en cas de excepcio
     * en els semafors.
     */
    public boolean eixirAparcament() {
        try {
            placesOcupates.acquire();
            placesLluires.release();

            return true;
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
