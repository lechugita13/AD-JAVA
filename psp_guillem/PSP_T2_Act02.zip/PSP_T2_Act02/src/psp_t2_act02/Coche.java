/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_t2_act02;

/**
 *
 * @author Itzanh
 */
public class Coche implements Runnable {

    private int id;
    private MonitorAparcament monitor;

    public Coche(int id, MonitorAparcament monitor) {
        this.id = id;
        this.monitor = monitor;
    }

    @Override
    public void run() {
        this.monitor.entrarAparcament();
        System.out.println("El cotxe " + this.id + " ha entrat al aparcament.");
        try {
            Thread.sleep((long) (Math.random() * 3000));
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        this.monitor.eixirAparcament();
        System.out.println("El cotxe " + this.id + " sen ha anat del aparcament.");
    }

}
