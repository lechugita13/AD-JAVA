/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_t3_act01;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 *
 * @author Itzanh
 */
public class NsLookup {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String host = "147.156.200.249";
        //String host = "yahoo.com";

        if (esIp(host)) {
            trobarNomDelHost(host);
        } else {
            trobarAdrecesDeNom(host);
        }
    }

    /**
     * Valida una adreça IP amb una expressio regular que he copiat i enganxat
     * de la primera página que he vist en google.
     *
     * @param address pot contenir una adreça IP o un nom de domini
     * @return true si es una IPv4, o false si es cualquier altra cosa
     */
    private static boolean esIp(String address) {
        /*return address.matches("^([01]?\\\\d\\\\d?|2[0-4]\\\\d|25[0-5])\\\\.([01]?\\\\d\\\\d?|2[0-4]\\\\d|25[0-5])\\\\.\n"
         + "([01]?\\\\d\\\\d?|2[0-4]\\\\d|25[0-5])\\\\.([01]?\\\\d\\\\d?|2[0-4]\\\\d|25[0-5])$");*/
        return Pattern.compile("([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])"
                + "\\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])"
                + "\\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])"
                + "\\.([01]?[0-9]{1,2}|2[0-4][0-9]|25[0-5])").matcher(address).matches();
    }

    private static void trobarNomDelHost(String adrecaIP) {
        try {
            InetAddress addr = InetAddress.getByName(adrecaIP);
            System.out.println("Name " + addr.getHostName());
            System.out.println("Address " + addr.getHostAddress());
        } catch (UnknownHostException ex) {
            System.out.println("No es pot mostrar aquesta informacio. Comprova la adreça i la conexio de xarxa.");
        }
    }

    private static void trobarAdrecesDeNom(String nom) {
        try {
            for (InetAddress addr : InetAddress.getAllByName(nom)) {
                System.out.println("Address " + addr.getHostAddress());
                System.out.println("Name " + addr.getHostName());
            }
        } catch (UnknownHostException ex) {
            System.out.println("No es pot mostrar aquesta informacio. Comprova la adreça i la conexio de xarxa.");
        }
    }
}
