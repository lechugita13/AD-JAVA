package com.itzanchan.practica12_itzanhuerta.classes;

import java.io.Serializable;

public enum Tipo implements Serializable {
    R2D2,
    BENDER,
    WALLE
}
