/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package activitat_filosofs;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 *
 * @author sergi
 */
public class Activitat_Filosofs {

    final static int NFILÒSOFS = 5;
    final static int[][] PALETS = {
        {0, 4}, // filosofo 0
        {1, 0}, // filosofo 1
        {2, 1}, // filosofo 2
        {3, 2}, // filosofo 3
        {4, 3} // filosofo 4
    };

    final static Semaphore[] semaforo = new Semaphore[NFILÒSOFS];

    public static class Filosof extends Thread {

        private final int id;
        private final Semaphore[] SEMAFOR;
        private final int palilloL;
        private final int palilloR;

        public Filosof(int id, Semaphore[] semaforo) {
            this.id = id;
            this.SEMAFOR = semaforo;
            this.palilloL = PALETS[id][0];
            this.palilloR = PALETS[id][1];
        }

        protected void menjar() {

            if (SEMAFOR[palilloR].tryAcquire()) {
                if (SEMAFOR[palilloR].tryAcquire()) {
                    System.out.println("FILÒSOF " + id + " ESTÀ MENJANT. USA ELS PALETS " + palilloL + " I " + palilloR);
                    try {
                        int time = 0;
                        while (time <= 0) {
                            time = new Random().nextInt() % 2000;
                        }
                        sleep(time);
                    } catch (InterruptedException ex) {
                        System.out.println("Error : " + ex.toString());
                    }
                    System.out.println("Filòsof " + id + " acaba de menjar. Allibera els palets " + palilloL + " i " + palilloR);
                    SEMAFOR[palilloR].release();
                }
                SEMAFOR[palilloL].release();
            } else {
                System.out.println("Filòsofo " + id + " té fam.");
            }
        }

        protected void pensar() {
            System.out.println("Filòsof " + id + " està pensant.");
            try {
                int time = 0;
                while (time <= 0) {
                    time = new Random().nextInt() % 2000;
                }
                sleep(time);
            } catch (InterruptedException ex) {
                System.out.println("Error en pensar(): " + ex.toString());
            }
        }

        @Override
        public void run() {
            while (true) {
                pensar();
                menjar();
            }
        }
    }

    public static void main(String[] args) {
        for (int i = 0; i < NFILÒSOFS; i++) {
            semaforo[i] = new Semaphore(1);
        }

        for (int idFilosof = 0; idFilosof < NFILÒSOFS; idFilosof++) {
            new Filosof(idFilosof, semaforo).start();
        }
    }

}
