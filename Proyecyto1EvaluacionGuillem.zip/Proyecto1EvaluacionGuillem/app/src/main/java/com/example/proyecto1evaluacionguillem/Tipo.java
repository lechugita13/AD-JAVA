package com.example.proyecto1evaluacionguillem;

import java.io.Serializable;

public enum Tipo implements Serializable {
    TAJIMA,
    BARUDAN,
    BROTHER
}
