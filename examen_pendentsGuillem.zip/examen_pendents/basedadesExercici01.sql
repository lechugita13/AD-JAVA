CREATE DATABASE IF NOT EXISTS examenPendents;

USE examenPendents;

CREATE TABLE IF NOT EXISTS ordinadors (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	numserie CHAR(8) NOT NULL,
	ram INT(10) NOT NULL,
	hdd INT(10) NOT NULL,
	micro VARCHAR(50) NOT NULL
);

INSERT INTO ordinadors (numserie,ram,hdd,micro) VALUES ("INT-4567",16,2,"INTEL i7-10510U");
INSERT INTO ordinadors (numserie,ram,hdd,micro) VALUES ("INT-1237",8,1,"INTEL i5-10310U");
INSERT INTO ordinadors (numserie,ram,hdd,micro) VALUES ("AMD-2208",12,1,"AMD RYZEN 4000");
INSERT INTO ordinadors (numserie,ram,hdd,micro) VALUES ("AMD-0001",8,2,"AMD RADEON RX");
INSERT INTO ordinadors (numserie,ram,hdd,micro) VALUES ("INT-4567",16,2,"INTEL i9-9900KS");