<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Examen PHP Pendents</title>
		<link  rel="stylesheet" href="./css/estils.css" />			
	</head>
	<body>
		<div id="wrapper">
			<header id="cap">
				<?php					
					include './include/cap.php';					
				?>
			</header>
			<main id="contingut">
				<?php					
					include './include/contingut.php';					
				?>
			</main>
			<footer id="peu">
				<?php					
					include './include/peu.php';					
				?>
			</footer>
		</div>
	</body>
</html>
