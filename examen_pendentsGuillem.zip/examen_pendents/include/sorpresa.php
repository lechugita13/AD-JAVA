<?php
session_start();
	$sorpresa = $_SESSION['sorpresa'];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Exercici 02 : Sorpresa</title>
		<link  rel="stylesheet" href="../css/estilsProcessa.css" />
		<link  rel="stylesheet" href="../css/estilsSorpresa.css" />				
	</head>
	<body>
		<div id="wrapper">
			<header id="cap">
				<img src="../img/logophp.png" alt="logo PHP" class="fotocap" />
				<h1>Examen PHP Pendents :: Sorpresa</h1>
				<img src="../img/logophp.png" alt="logo PHP" class="fotocap" />
			</header>
			<main id="contingut">
			
			<!-- Resultat exercici 02 - Sorpresa -->
				<article class="exercici">
					<?php
					$imatgeS = './../img/sorpresa.png';
                       for ($i=0; $i < $sorpresa ; $i++) { 
						  
						echo '<img class="imatgequadrat" src="' . $imatgeS . '" alt="imatge seleccionada"/>';

					   }
					?>
				</article>			
                <p><a href="../index.php#exercici02">Torna a l'inici</a></p>
			</main>
			<footer id="peu">
				<?php					
					include 'peu.php';					
				?>
			</footer>
		</div>
	</body>
</html>
