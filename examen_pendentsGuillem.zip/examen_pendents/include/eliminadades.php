<?php
session_start();


	include_once './funcions.php';
   $id = $_GET["id"];
   echo $id;

	elimina_dades($id);

	header('Location:../index.php#exercici01');
	exit();
?>