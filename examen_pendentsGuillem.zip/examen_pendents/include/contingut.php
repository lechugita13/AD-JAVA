<div id="exercicis">
    <div id="exercici01">
        <h2>Exercici 01</h2>
        <h3 class="destacat">Enunciat: Dades Ordinadors</h3>
        <ul>
            <li>En camps ocults obtenim les dades de connexió a la base de dades: Servidor, Usuari, Contrasenya, Base de dades i taula.</li>
            <li>Per defecte, l'usuari és root i la contrasenya en blanc. Canvia'ls si cal.</li>
            <li>Obtenim les dades de connexió en processaExercici01.php i les introduïm en variables de sessió.</li>
            <li>També hem d'obtenir el valor de la variable GET accio que està en el paràmetre action del formulari.</li>
            <li>El valor de la variable GET accio des del formulari de la pàgina inicial és insert</li>
            <li>Tots els camps del formulari són obligatoris.</li>
            <li>Quan introduïm totes les dades correctament, s'haurà d'inserir la informació en la taula ordinadors.</li>
            <li>S'ha de comprovar que el número de sèrie segueix el format INT-XXXX o AMD-XXXX, on XXXX són números.
            <li>Utilitza les funcions <strong>explode()</strong> i <strong>is_numeric()</strong> per a les comprovacions</li>
            </li>
            <li>Si segueix el format, s'insereix la informació i es mostren tots els registres.</li>
            <li>Si no segueix el format, no s'insereix la informació, s'indica que no compleix la condició i igualment es mostren tots els registres.</li>
            <li>Quan es mostren les dades dels ordinadors (en etiquetes h4), s'afegeix un enllaç que permeta eliminar cada element en particular, en funció del seu camp id.</li>
            <li>Quan es fa clic a l'enllaç, s'ha d'anar al fitxer eliminadades.php, eliminar l'element amb l'id indicat i tornar de nou al fitxer processaExercici01.php, amb una variable GET accio amb valor delete.</li>
            <li>Quan s'arriba a processaExercici01.php des d'eliminadades.php, només s'ha de mostrar la informació, no s'ha d'inserir cap dada.</li>
            <li>En el fitxer funcions.php s'han de crear 3 funcions:
				<ul>
					<li><strong>mostra_dades()</strong>: mostrar per pantalla tots els registres de la taula, afegint l'enllaç per eliminar-los.</li>
					<li><strong>insereix_dades($numserie,$ram,$hdd,$micro)</strong>: per inserir en la taula les dades que es passen. Retorna un valor booleà indicant si el número de sèrie és incorrecte.</li>
					<li><strong>elimina_dades($id)</strong>: elimina de la taula el registre amb el valor id indicat.</li>
				</ul>
            </li>
            <li>El fitxer funcions.php s'ha de carregar prèviament per poder utilitzar les funcions que conté.</li>
            <li>Les tres funcions obrin la connexió a la base de dades i la tanquen abans d'acabar.</li>
        </ul>
        <form id="form_exercici01" method="POST" action="include/processaExercici01.php?accio=insert"  enctype="multipart/form-data">
            <input type="hidden" value="localhost" name="servidor" id="servidor" />
            <input type="hidden" value="root" name="usuari" id="usuari" />
            <input type="hidden" value="" name="contrasenya" id="contrasenya" />
            <input type="hidden" value="examenpendents" name="basedades" id="basedades" />
            <input type="hidden" value="ordinadors" name="taula" id="taula" />
            <div class="filaform">
                <span>Número Sèrie:</span>
                <span><input type="text" name="numserie" id="numserie" required placeholder="Format: INT-XXXX o AMD-XXXX" size="30"/> (Exemple: INT-6754)</span>
            </div>
            <div class="filaform">
                <span>RAM:</span>
                <span><input type="number" name="ram" id="ram"  required placeholder="en GBytes"/> (GB)</span>
            </div>
            <div class="filaform">
                <span>HDD:</span>
                <span><input type="number" name="hdd" id="hdd"  required placeholder="en TBytes"/> (TB)</span>
            </div>
            <div class="filaform">
                <span>Microprocessador:</span>
                <span><input type="text" name="micro" id="micro"  required placeholder="Marca i model" size="30"/></span>
            </div>
            <div class="filaform">
                <span><input id="submitform" name="submitform" type="submit" value="Insereix ordinador"/></span>
            </div>
        </form>
        
    </div><!--final exercici 01-->


    <div id="exercici02">
        <h2>Exercici 02</h2>
        <h3 class="destacat">Enunciat: Quadrat d'imatges</h3>
        <ul>
            <li>En un camp ocult del formulari html hi ha fixat un número sorpresa (per defecte 500).</li>
            <li>L'usuari introdueix un número a la casella del formulari.</li>
            <li>Si el número està en el rang entre 3 i 10 (inclosos), en <strong>processaExercici02.php</strong> es mostrarà un quadrat d'imatges amb tantes imatges per costat com indique l'usuari amb el número.
                <ul>
                    <li>En els cantons ficarem la imatge <strong>cavallet.png</strong>. <img src="img/cavallet.png" class="imatgequadrat" /></li>
                    <li>En la resta, ficarem la imatge <strong>estrella.png</strong>.<img src="img/estrella.png" class="imatgequadrat" /></li>
                    <li>S'ha d'assignar la classe <em>imatgequadrat</em> a les etiquetes img.</li>
                    <li>Les imatges dels cantons tenen un enllaç, quan es fa clic a sobre, s'ha de tornar a la pròpia pàgina i canviar la imatge del cavallet per <strong>sorpresa.png</strong>. <img src="img/sorpresa.png" class="imatgequadrat" /></li>
                </ul>
            </li>
            <li>Si el número no està en el rang entre 3 i 10 (inclosos), en <strong>processaExercici02.php</strong> es mostra un missatge indicant-ho i la imatge <strong>peix.png</strong>.<img src="img/peix.png" class="imatgequadrat" /></li>
            <li>Si es tracta del número sorpresa, s'ha d'obrir, des de <strong>processaExercici02.php</strong>, la pàgina <strong>sorpresa.php</strong>, mostrant el número i la imatge <strong>sorpresa.png</strong> tantes vegades com el número indique.</li>
            <li>Si es canvia el número sorpresa en el camp ocult del formulari, s'ha de comprovar que també canvia en la <strong>sorpresa.php</strong>.</li>
        </ul>
        <form id="form_exercici02" method="POST" action="include/processaExercici02.php">
            <input type="hidden" value="500" name="sorpresa" id="sorpresa" />
            <div class="filaform">
                <span>Número</span>
                <span><input type="text" name="numero" id="numero" required /></span>
            </div>
            <div class="filaform">
                <span><input id="submitform" name="submitform" type="submit" value="Envia"/></span>
            </div>
        </form>
    </div> <!--final exercici 02-->
</div>
