<?php
	session_start();

	$_SESSION['servidor'] = $_POST['servidor'];
	$_SESSION['usuari'] = $_POST['usuari'];
	$_SESSION["contrasenya"] = $_POST["contrasenya"];
	$_SESSION["basedades"] = $_POST["basedades"];

	$_SESSION["usuari"] = 'root';
	$_SESSION["contrasenya"] = '';

	$numserie = $_POST["numserie"];
	$ram = $_POST["ram"];
	$hdd = $_POST["hdd"];
	$micro = $_POST["micro"];
	$error = false;
	$errorProduit = '';

	

	
	include_once './funcions.php';
	

	insereix_dades($numserie,$ram,$hdd,$micro);

	
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Examen PHP Pendents :: Exercici 01</title>
		<link  rel="stylesheet" href="../css/estilsProcessa.css" />			
	</head>
	<body>
		<div id="wrapper">
			<header id="cap">
				<img src="../img/logophp.png" alt="logo PHP" class="fotocap" />
				<h1>Examen PHP Pendents :: Exercici 01</h1>
				<img src="../img/logophp.png" alt="logo PHP" class="fotocap" />
			</header>
			<main id="contingut">
			
			<!-- Resultat exercici 01 -->
				<article class="exercici">
					<?php
						echo mostra_dades();
					?>
				</article>			
                                 <p><a href="../index.php#exercici01">Torna a l'inici</a></p>
			</main>
			<footer id="peu">
				<?php					
					include 'peu.php';					
				?>
			</footer>
		</div>
	</body>
</html>
