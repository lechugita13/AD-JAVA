<?php
		echo "<p>
						IES Lluís Simarro<br/>
						Entorns de Desenvolupament<br/>
						Curs 2019/2020<br/>
                    </p>";
?>
