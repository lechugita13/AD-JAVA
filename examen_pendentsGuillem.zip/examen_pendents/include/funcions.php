<?php
    //funcio per inserir una entrada de la base de dades
	//si el número de sèrie no segueix el patró INT-XXXX o AMD-XXXX, no insereix cap dada
	//si el número de sèrie és incorrecte, retorna true
	//si el número de sèrie és correcte, retorna false
    //tots els camps tenen valor, perquè hem obligat en el formulari
		
    function insereix_dades($numserie,$ram,$hdd,$micro){
		$conexio = mysqli_connect($_SESSION["servidor"],'root','',$_SESSION["basedades"]);

	if(!$conexio){
		echo 'Error en la conexio a la base';
		return;
	}
		echo $numserie;
		$numseriePartit =explode('-',$numserie);
		$primer = $numseriePartit[0];
		
		echo $primer;
		
		if (strcasecmp($primer,'INT') == 0 || strcasecmp($primer,'AMD') == 0) {
			if (strlen($numseriePartit[1])==4 && is_numeric($numseriePartit[1])) {
				$sql = '';
				$sql = "INSERT INTO `examenPendents`.`ordinadors` (`numserie`,`ram`,`hdd`,`micro`) VALUES "
						."('" .$numserie ."','". $ram ."','". $hdd ."','". $micro ."');";

		mysqli_query($conexio,$sql);
			}
		}else{
			echo 'No sa insertat be comproba el numero de serie';
		}
		
		$conexio->close();
	}		

	
    
	//funcio per eliminar una entrada de la base de dades en funció de l'id que se li passa
	function elimina_dades($id){
		
		$conexio = mysqli_connect($_SESSION["servidor"],'root','',$_SESSION["basedades"]);

	if(!$conexio){
		echo 'Error en la conexio a la base';
		return;
	}
		$sql = '';
		$sql = "DELETE FROM `ordinadors` WHERE `id` = '".$id."';";

		mysqli_query($conexio,$sql);
		
		$conexio->close();
	}

	//funció per mostrar els les dades dels ordinadors de la base de dades, ha d'afegir un enllaç per eliminar en funció del camp id
	//utilitza etiquetes h4 per mostrar les dades de cada ordinador
	function mostra_dades(){
		$conexio = mysqli_connect($_SESSION["servidor"],'root','',$_SESSION["basedades"]);

		if(!$conexio){
			echo 'Error en la conexio a la base';
			return;
		}

		$sql = 'SELECT * FROM ordinadors';
		$registreBD = mysqli_query($conexio,$sql);

		if (mysqli_num_rows($registreBD) > 0) {
		$resultat = '<h4>';
		$resultat = $resultat . '<h4> Hi han registres en la taula </h4> <br>';
		while($fila = mysqli_fetch_assoc($registreBD)){
			
			echo '<h4>'.$fila['id'] . $fila['numserie'] . $fila['ram'] . $fila['micro'].'<a href="./eliminadades.php?id='.$fila['id'].'"> Eliminar</a>'.'<br>'.'</h4>';
		}
		
		$resultat = $resultat . '</h4>';
		
	}else{
		$resultat = 'No hi ha res';
	}
	$conexio->close();
	return $resultat;
}
