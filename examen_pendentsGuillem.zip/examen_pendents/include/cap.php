<?php
	echo "<img src=\"img/logophp.png\" alt=\"logo PHP\" class=\"fotocap\" />";

	echo "<h1>Examen Pendents PHP 19/20</h1>";

	echo "<img src=\"img/logophp.png\" alt=\"logo PHP\" class=\"fotocap\" />";
?>
