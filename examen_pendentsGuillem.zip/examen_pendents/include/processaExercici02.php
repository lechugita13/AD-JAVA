<?php
session_start();
	$numero = $_POST['numero'];
	$coincideix = false;
	if ($numero>2 && $numero<11) {
		$coincideix = true;
	}
	$sorpresaBool = false;
	$sorpresa = $_POST['sorpresa'];
	$_SESSION['sorpresa']=$sorpresa;
	if ($numero == $sorpresa) {
		$sorpresaBool = true;
	}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Examen PHP Pendents :: Exercici 02</title>
		<link  rel="stylesheet" href="../css/estilsProcessa.css" />			
	</head>
	<body>
		<div id="wrapper">
			<header id="cap">
				<img src="../img/logophp.png" alt="logo PHP" class="fotocap" />
				<h1>Examen PHP Pendents :: Exercici 02</h1>
				<img src="../img/logophp.png" alt="logo PHP" class="fotocap" />
			</header>
			<main id="contingut">
			
			<!-- Resultat exercici 02 -->
				<article class="exercici">
					<?php
					$imatgeE = './../img/estrella.png';
					$imatgeC = './../img/cavallet.png';
					$imatgeS = './../img/sorpresa.png';
					if($coincideix == true){
						for ($i=0; $i < $numero; $i++) { 
							echo '<br>';
							
							for ($j=0; $j < $numero; $j++) { 
								if ($i == 0 && $j==0) {
									$imgProba = '<img class="imatgequadrat" src="' . $imatgeC . '" alt="imatge seleccionada"/>';

									//echo $imgProba;
									echo '<a href="./processaExercici02.php?canton1=false">'.$imgProba.'</a>'; 
									//$getCanton=$_GET["canton1"];
									//if ($getCanton == true) {
										//echo '<img class="imatgequadrat" src="' . $imatgeS . '" alt="imatge seleccionada"/>';
									//}
									
									
								}else if($i==$numero-1 && $j == $numero-1){
									$imgProba = '<img class="imatgequadrat" src="' . $imatgeC . '" alt="imatge seleccionada"/>';
									echo '<a href="./processaExercici02.php?canton1=false">'.$imgProba.'</a>'; 

								}else if($i==$numero-1 && $j == 0){
									$imgProba = '<img class="imatgequadrat" src="' . $imatgeC . '" alt="imatge seleccionada"/>';
									echo '<a href="./processaExercici02.php?canton1=false">'.$imgProba.'</a>'; 
								}else if($i==0 && $j == $numero-1){
									$imgProba = '<img class="imatgequadrat" src="' . $imatgeC . '" alt="imatge seleccionada"/>';

									echo '<a href="./processaExercici02.php?canton1=false">'.$imgProba.'</a>'; 
								}else{
									echo '<img class="imatgequadrat" src="' . $imatgeE . '" alt="imatge seleccionada"/>';
								}
								
							}
						}
						
					}else if($sorpresa==true){
						header('Location:../include/sorpresa.php');
					
					}else{
						echo '<h4>El numero no esta dins del rang 3-10.</h4>';
						echo '<img src =./../img/peix.png alt ="imatgeseleccionada"/>';
					}
						
						
					?>
				</article>			
                                <p><a href="../index.php#exercici02">Torna a l'inici</a></p>
			</main>
			<footer id="peu">
				<?php					
					include 'peu.php';					
				?>
			</footer>
		</div>
	</body>
</html>
